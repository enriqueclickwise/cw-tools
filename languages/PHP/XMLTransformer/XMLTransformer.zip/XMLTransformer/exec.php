<?php
function transform($xmlfilename, $xslfilename, $finalxmlfilename){
    exec('xsltproc '.$xslfilename.' '.$xmlfilename.' > '.$finalxmlfilename);
}
?>