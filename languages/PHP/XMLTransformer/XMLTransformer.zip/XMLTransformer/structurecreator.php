<?php
    function createStructure($structure, $xslpath){

    }
?>