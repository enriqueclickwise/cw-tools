<?php
include_once 'exec.php';
include_once 'parse.php';
include_once 'setconf.php';
include_once 'structurecreator.php';
    // $xmldata =  array(
    //                 array(
    //                     'xmlfilename' => 'Files/Electronicamente/Electronicamente.xml',
    //                     'xslfilename' => 'structure.xsl',
    //                     'finalxmlfilename' => 'Files/Electronicamente/CW-Electronicamente.xml',
    //                 ),
    // );
        // foreach ($xmldata as $data){
    //     $xmlfilename = $data['xmlfilename'];
    //     $xslfilename = $data['xslfilename'];
    //     $finalxmlfilename = $data['finalxmlfilename'];
    //     parse($xmlfilename);
    //     transform($xmlfilename, $xslfilename, $finalxmlfilename);
    // }
    $jsonname = 'conf.json';
    readConf($jsonname);
?>