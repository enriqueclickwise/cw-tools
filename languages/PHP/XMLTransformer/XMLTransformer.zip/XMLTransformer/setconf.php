<?php
    function readConf($jsonname){
        $jsontext = file_get_contents($jsonname);
        $json = json_decode($jsontext);
        print_r($json);
        $i = 0;
        foreach($json as $conf){
            $xmlfilename = $conf[$i]->xmlfilename;
            $xslfilename = $conf[$i]->xslfilename;
            $finalxmlfilename = $conf[$i]->finalxmlfilename;
            $xslpath = $conf[$i]->xslpath;
            $structure = $conf[$i]->structure;
            $xslid = $conf[$i]->structure[$i]->id;
            $xslname = $conf[$i]->structure[$i]->name;
            $xsldescription = $conf[$i]->structure[$i]->description;
            $xsllink = $conf[$i]->structure[$i]->link;
            $xslactualprice = $conf[$i]->structure[$i]->price;
            $xslimage = $conf[$i]->structure[$i]->image;
            $xsllastprice = $conf[$i]->structure[$i]->lastprice;
            $xslcategory = $conf[$i]->structure[$i]->category;
            $xslbrand = $conf[$i]->structure[$i]->brand;
            // createStructure($structure, $xslpath);
            $i++;
        }
    }
?>