<?php
    function parse($xmlfilename){
        $xml = file_get_contents($xmlfilename);
        $finalxml = str_replace('& ','&amp; ',$xml);
        file_put_contents($xmlfilename, $finalxml);
    }
?>